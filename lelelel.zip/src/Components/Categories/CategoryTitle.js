const CategoryTitle = (props) => {
  return <div>{props.children}</div>;
};

export default CategoryTitle;
